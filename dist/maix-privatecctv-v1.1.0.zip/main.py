# main.py - Modularized main entry point for Private CCTV System

from maix import app, image, time
from debug_config import DebugLogger
from tools.wifi_connect import connect_wifi
from tools.video_record import VideoRecorder
from tools.skeleton_saver import SkeletonSaver2D
from tools.bed_area_checker import BedAreaChecker
from tools.floor_area_checker import FloorAreaChecker
from tools.chair_area_checker import ChairAreaChecker
from tools.couch_area_checker import CouchAreaChecker
from tools.bench_area_checker import BenchAreaChecker
from tools.safety_judgment import SafetyJudgment

# Import modular components
from config import (
    initialize_camera, save_camera_info, STREAMING_HTTP_URL,
    BACKGROUND_PATH, MIN_HUMAN_FRAMES_TO_START, NO_HUMAN_FRAMES_TO_STOP,
    MAX_RECORDING_DURATION_MS, UPDATE_INTERVAL_MS, NO_HUMAN_CONFIRM_FRAMES,
    GC_INTERVAL_MS, NO_HUMAN_SECONDS_TO_STOP
)
from camera_manager import (
    initialize_cameras, load_fonts,
)
from control_manager import (
    load_initial_flags, get_control_flags, send_background_updated, update_control_flags_from_server,
    update_control_flag, get_flag, camera_state_manager, register_status_change_callback,
    initialize_bed_area_checker, update_bed_area_polygons, load_bed_areas,
    initialize_floor_area_checker, update_floor_area_polygons, load_floor_areas,
    initialize_chair_area_checker, update_chair_area_polygons, load_chair_areas,
    initialize_couch_area_checker, update_couch_area_polygons, load_couch_areas,
    initialize_bench_area_checker, update_bench_area_polygons, load_bench_areas
)
from workers import (
    CameraStateSyncWorker, StateReporterWorker, FrameUploadWorker,
    CommandReceiver, PingWorker, get_received_commands, handle_command,
    update_is_recording,
    TracksSenderWorker,
    set_tracks_worker, update_latest_tracks, mark_tracks_as_ready
)
from tracking import (
    update_tracks, process_track, set_fps
)
from tools.time_utils import time_ms, TaskProfiler, get_timestamp_str

import os
import queue
import gc

logger = DebugLogger("MAIN", instance_enable=False)

# ============================================
# HELPER FUNCTIONS
# ============================================

def merge_background_with_mask(old_background, new_frame, processed_tracks, padding=20, step=4):
    """Merge old background with new frame, masking out areas where humans are present.

    Uses keypoints for precise masking: body bbox and head area (ear-nose-ear).

    Args:
        old_background: Existing background image (to preserve human areas)
        new_frame: New raw frame (to update non-human areas)
        processed_tracks: List of track dicts with 'bbox' and 'keypoints'
        padding: Extra padding around body bboxes and head base
        step: Pixel step for copying (higher = faster but blockier)

    Returns:
        Merged image with old background in human areas, new frame elsewhere
    """
    import math
    
    head_padding_factor = 0.8

    # Start with a copy of the new frame
    merged = new_frame.copy()

    width = new_frame.width()
    height = new_frame.height()

    # For each track, mask body bbox and head area
    for track in processed_tracks:
        bbox = track.get("bbox")
        keypoints = track.get("keypoints")

        if not bbox:
            continue

        x, y, w, h = bbox

        # 1. Mask body bbox with normal padding
        x1 = max(0, int(x - padding))
        y1 = max(0, int(y - padding))
        x2 = min(width, int(x + w + padding))
        y2 = min(height, int(y + h + padding))

        for py in range(y1, y2, step):
            for px in range(x1, x2, step):
                try:
                    pixel = old_background[px, py]
                    merged[px, py] = pixel
                except (IndexError, OSError):
                    pass

        # 2. Mask head area (ear-nose-ear) with proportional padding
        if keypoints and len(keypoints) >= 10:
            # Extract nose and ear coordinates
            nose_x, nose_y = keypoints[0], keypoints[1]
            left_ear_x, left_ear_y = keypoints[6], keypoints[7]
            right_ear_x, right_ear_y = keypoints[8], keypoints[9]

            # Check if keypoints are valid (not 0,0 or near it)
            if nose_x > 0 and nose_y > 0:
                # Calculate distances from nose to ears
                nose_to_left_ear_dist = 0
                nose_to_right_ear_dist = 0

                if left_ear_x > 0 and left_ear_y > 0:
                    nose_to_left_ear_dist = math.sqrt((nose_x - left_ear_x)**2 + (nose_y - left_ear_y)**2)

                if right_ear_x > 0 and right_ear_y > 0:
                    nose_to_right_ear_dist = math.sqrt((nose_x - right_ear_x)**2 + (nose_y - right_ear_y)**2)

                # Use the longer distance, proportionally scale padding
                max_ear_nose_dist = max(nose_to_left_ear_dist, nose_to_right_ear_dist)

                # Calculate proportional head padding: base (padding) + (longest ear-nose distance)
                if max_ear_nose_dist > 0:
                    head_padding = int(max_ear_nose_dist * head_padding_factor)
                else:
                    head_padding = padding

                # Calculate head bounding box from ear-nose-ear
                if left_ear_x > 0 and right_ear_x > 0:
                    # Both ears visible
                    head_x1 = int(min(left_ear_x, right_ear_x) - head_padding)
                    head_x2 = int(max(left_ear_x, right_ear_x) + head_padding)
                else:
                    # One or both ears not visible, use nose as center
                    head_x1 = int(nose_x - head_padding)
                    head_x2 = int(nose_x + head_padding)

                head_y1 = int(min(nose_y, left_ear_y if left_ear_y > 0 else nose_y, right_ear_y if right_ear_y > 0 else nose_y) - head_padding)
                head_y2 = int(max(nose_y, left_ear_y if left_ear_y > 0 else nose_y, right_ear_y if right_ear_y > 0 else nose_y) + head_padding)

                # Clamp to image bounds
                head_x1 = max(0, head_x1)
                head_y1 = max(0, head_y1)
                head_x2 = min(width, head_x2)
                head_y2 = min(height, head_y2)

                # Copy head area from old background
                for py in range(head_y1, head_y2, step):
                    for px in range(head_x1, head_x2, step):
                        try:
                            pixel = old_background[px, py]
                            merged[px, py] = pixel
                        except (IndexError, OSError):
                            pass

    return merged

# ============================================
# MAIN INITIALIZATION
# ============================================

def main():
    """Main entry point"""
    # 1. Initialize camera identity
    CAMERA_ID, CAMERA_NAME, registration_status, local_ip = initialize_camera()
    
    # 2. Connect to WiFi
    server_ip = connect_wifi("MaixCAM-Wifi", "maixcamwifi")
    logger.print("MAIN", "Camera IP: %s", server_ip)
    
    # 3. Initialize cameras and detectors (RTMP removed, now returns 4 values)
    cam, disp, pose_extractor, detector = initialize_cameras()
    load_fonts()
    
    # 4. Initialize tools
    recorder = VideoRecorder()
    skeleton_saver_2d = SkeletonSaver2D()

    # 5. Initialize area checkers

    bed_area_checker = BedAreaChecker(too_long_threshold_ms=5000)
    initialize_bed_area_checker(bed_area_checker)

    floor_area_checker = FloorAreaChecker()
    initialize_floor_area_checker(floor_area_checker)

    chair_area_checker = ChairAreaChecker()
    initialize_chair_area_checker(chair_area_checker)

    couch_area_checker = CouchAreaChecker()
    initialize_couch_area_checker(couch_area_checker)

    bench_area_checker = BenchAreaChecker()
    initialize_bench_area_checker(bench_area_checker)

    # 6. Load initial configuration
    logger.print("MAIN", "=== Loading Configuration ===")
    load_initial_flags()
    control_flags = get_control_flags()  # Get loaded flags including check_method

    # Initialize SafetyJudgment with all three checkers
    # Get check_method from control_flags (default: 3 = TORSO_HEAD)
    check_method_value = control_flags.get("check_method", 3)
    from tools.polygon_checker import CheckMethod

    # Map integer value to CheckMethod enum
    check_method_map = {
        1: CheckMethod.HIP,
        2: CheckMethod.TORSO,
        3: CheckMethod.TORSO_HEAD,
        4: CheckMethod.TORSO_HEAD_KNEES,
        5: CheckMethod.FULL_BODY
    }
    check_method = check_method_map.get(check_method_value, CheckMethod.TORSO_HEAD)

    safety_judgment = SafetyJudgment(
        bed_area_checker=bed_area_checker,
        floor_area_checker=floor_area_checker,
        chair_area_checker=chair_area_checker,
        couch_area_checker=couch_area_checker,
        bench_area_checker=bench_area_checker,
        check_method=check_method
    )
    


    initial_bed_areas = load_bed_areas()
    update_bed_area_polygons(initial_bed_areas)

    initial_floor_areas = load_floor_areas()
    update_floor_area_polygons(initial_floor_areas)

    initial_chair_areas = load_chair_areas()
    update_chair_area_polygons(initial_chair_areas)

    initial_couch_areas = load_couch_areas()
    update_couch_area_polygons(initial_couch_areas)

    initial_bench_areas = load_bench_areas()
    update_bench_area_polygons(initial_bench_areas)
    
    # 7. Load or create background image
    if os.path.exists(BACKGROUND_PATH):
        from maix import image as img_module
        background_img = image.load(BACKGROUND_PATH, format=image.Format.FMT_RGB888)
        logger.print("MAIN", "Loaded background image from file")
    else:
        background_img = cam.read().copy()
        background_img.save(BACKGROUND_PATH)
        logger.print("MAIN", "Created new background image")
    
    # ============================================
    # ASYNC WORKERS SETUP
    # ============================================
    flags_queue = queue.Queue(maxsize=10)
    bed_areas_queue = queue.Queue(maxsize=5)
    floor_areas_queue = queue.Queue(maxsize=5)
    chair_areas_queue = queue.Queue(maxsize=5)
    couch_areas_queue = queue.Queue(maxsize=5)
    bench_areas_queue = queue.Queue(maxsize=5)

    # Start command server
    command_receiver = CommandReceiver()
    command_receiver.start()

    # Start async workers
    logger.print("MAIN", "Starting async workers...")
    flag_sync_worker = CameraStateSyncWorker(
        flags_queue, STREAMING_HTTP_URL, CAMERA_ID,
        bed_areas_queue=bed_areas_queue, floor_areas_queue=floor_areas_queue,
        chair_areas_queue=chair_areas_queue, couch_areas_queue=couch_areas_queue,
        bench_areas_queue=bench_areas_queue
    )
    state_reporter_worker = StateReporterWorker(STREAMING_HTTP_URL, CAMERA_ID)
    frame_upload_worker = FrameUploadWorker(STREAMING_HTTP_URL, CAMERA_ID, profiler_enabled=True)
    ping_worker = PingWorker(STREAMING_HTTP_URL, CAMERA_ID)

    flag_sync_worker.start()
    state_reporter_worker.start()
    frame_upload_worker.start()
    ping_worker.start()


    # Start Tracks Sender Worker (always runs to send all tracks to Streaming Server)
    tracks_sender = TracksSenderWorker(CAMERA_ID, profiler_enabled=False)
    set_tracks_worker(tracks_sender)
    tracks_sender.start()
    logger.print("MAIN", "[TracksSender] Worker started")
    
    logger.print("MAIN", "Async workers started successfully")
    
    # Register callback for registration status changes
    def on_registration_status_changed(new_status):
        """Callback to handle registration status changes"""
        nonlocal registration_status
        old_status = registration_status
        registration_status = new_status
        logger.print("MAIN", "[StatusChange] Registration status changed: %s -> %s", old_status, new_status)
        
        # If camera was approved, save the updated info
        if new_status == "registered" and old_status == "pending":
            save_camera_info(CAMERA_ID, CAMERA_NAME, "registered", local_ip)
    
    register_status_change_callback(on_registration_status_changed)
    
    # ============================================
    # STATE VARIABLES
    # ============================================
    frame_id = 0
    human_presence_history = []
    recording_start_time = 0
    is_recording = False
    background_update_in_progress = False
    background_update_needed = False  # Flag for deferred background update with masking
    prev_human_present = False
    no_human_counter = 0
    last_update_ms = time_ms()
    last_gc_time = time_ms()
    streaming_server_available = True
    frame_profiler = TaskProfiler(task_name="Main", enabled=False)
    frame_profiler.register_subtasks([
        "async_updates",
        "commands",
        "background_check",
        "human detect",
        "display_prep",
        "pose_extraction",
        "tracking",
        "recording",
        "display",
        "frame_upload"
    ])
    frame_start_time = time_ms()
    
    # caches last known track, will only be cleared after `cached_tracks_timeout` of no tracks detected.
    # is used for selective background updates
    cached_tracks = None
    cached_tracks_timeout = 3000 # 3s
    cached_tracks_last_updated = 0
    
    # ============================================
    # MAIN LOOP
    # ============================================
    frame_counter = 0
    
    logger.print("MAIN", "=== Camera Stream Started ===")
    control_flags = get_control_flags()
    logger.print("MAIN", "Final Configuration:")
    logger.print("MAIN", "  Camera: %s (%s)", CAMERA_NAME, CAMERA_ID)
    logger.print("MAIN", "  Status: %s", registration_status)
    logger.print("MAIN", "  Recording: %s", 'ENABLED' if control_flags.get('record') else 'DISABLED')
    logger.print("MAIN", "  UI Rendering: DISABLED (no text/skeleton)")
    logger.print("MAIN", "  Display: DISABLED")
    logger.print("MAIN", "  Fall Algorithm: %s", control_flags.get('fall_algorithm'))
    
    # Upload background image to server at startup
    if streaming_server_available and background_img is not None:
        try:
            jpeg_bytes = background_img.to_jpeg(quality=70).to_bytes(copy=False)
            frame_upload_worker.update_background(jpeg_bytes)
            logger.print("MAIN", "[BACKGROUND] Background queued for upload at startup")
        except Exception as e:
            logger.print("MAIN", "[BACKGROUND] Failed to queue background for upload at startup: %s", e)
    
    while not app.need_exit():
        # Start frame profiling
        frame_profiler.start_frame()
        
        # 1. Process async updates from workers
        frame_profiler.start_task("async_updates")
        try:
            while not flags_queue.empty():
                msg_type, data = flags_queue.get_nowait()
                if msg_type == "flags_update":
                    flags_updated = update_control_flags_from_server(data)
                    if flags_updated:
                        streaming_server_available = True
        except queue.Empty:
            pass



        try:
            while not bed_areas_queue.empty():
                msg_type, data = bed_areas_queue.get_nowait()
                if msg_type == "bed_areas_update":
                    if isinstance(data, list):
                        update_bed_area_polygons(data)
        except queue.Empty:
            pass

        try:
            while not chair_areas_queue.empty():
                msg_type, data = chair_areas_queue.get_nowait()
                if msg_type == "chair_areas_update":
                    if isinstance(data, list):
                        update_chair_area_polygons(data)
        except queue.Empty:
            pass

        try:
            while not couch_areas_queue.empty():
                msg_type, data = couch_areas_queue.get_nowait()
                if msg_type == "couch_areas_update":
                    if isinstance(data, list):
                        update_couch_area_polygons(data)
        except queue.Empty:
            pass

        try:
            while not bench_areas_queue.empty():
                msg_type, data = bench_areas_queue.get_nowait()
                if msg_type == "bench_areas_update":
                    if isinstance(data, list):
                        update_bench_area_polygons(data)
        except queue.Empty:
            pass

        try:
            while not floor_areas_queue.empty():
                msg_type, data = floor_areas_queue.get_nowait()
                if msg_type == "floor_areas_update":
                    if isinstance(data, list):
                        update_floor_area_polygons(data)
        except queue.Empty:
            pass
        frame_profiler.end_task("async_updates")
        
        # 2. Process received commands
        frame_profiler.start_task("commands")
        commands = get_received_commands()
        for cmd_data in commands:
            handle_command(
                cmd_data.get("command"), 
                cmd_data.get("value"),
                CAMERA_ID,
                registration_status,
                lambda cid, cname, status, ip: save_camera_info(cid, cname, status, ip)
            )
            if cmd_data.get("command") == "approve_camera":
                camera_state_manager.set_registration_status("registered")
        frame_profiler.end_task("commands")
        
        # 3. Camera Read
        raw_img = cam.read()
        
        # 4. Check for background update request
        frame_profiler.start_task("background_check")
        if get_flag("set_background", False) and not background_update_in_progress and not get_flag("_background_update_pending", False):
            logger.print("MAIN", "[BACKGROUND] Starting background update...")
            background_img = raw_img.copy()
            background_img.save(BACKGROUND_PATH)
            background_update_in_progress = True
            update_control_flag("set_background", False)
            # Upload background image to server via FrameUploadWorker
            if streaming_server_available:
                try:
                    jpeg_bytes = background_img.to_jpeg(quality=70).to_bytes(copy=False)
                    frame_upload_worker.update_background(jpeg_bytes)
                    logger.print("MAIN", "[BACKGROUND] Background queued for upload to server")
                except Exception as e:
                    logger.print("MAIN", "[BACKGROUND] Failed to queue background for upload: %s", e)
            send_background_updated(time.time())
            background_update_in_progress = False
            logger.print("MAIN", "[BACKGROUND] Background updated")
        frame_profiler.end_task("background_check")
        
        # 5. Person Detection
        frame_profiler.start_task("human detect")
        objs_det = detector.detect(raw_img, conf_th=0.5, iou_th=0.45)
        current_human_present = any(detector.labels[obj.class_id] == "person" for obj in objs_det)
        
        # Auto background update logic
        if get_flag("auto_update_bg", False):
            if prev_human_present and not current_human_present:
                no_human_counter += 1
                if no_human_counter >= NO_HUMAN_CONFIRM_FRAMES:
                    # No humans present, can update background immediately
                    background_img = raw_img.copy()
                    background_img.save(BACKGROUND_PATH)
                    # Upload background image to server via FrameUploadWorker
                    if streaming_server_available:
                        try:
                            jpeg_bytes = background_img.to_jpeg(quality=70).to_bytes(copy=False)
                            frame_upload_worker.update_background(jpeg_bytes)
                            logger.print("MAIN", "[BACKGROUND] Auto-update background queued for upload (no humans)")
                        except Exception as e:
                            logger.print("MAIN", "[BACKGROUND] Auto-update failed to queue background: %s", e)
                    last_update_ms = time_ms()
                    no_human_counter = 0
            else:
                no_human_counter = 0
                if time_ms() - last_update_ms > UPDATE_INTERVAL_MS:
                    # Periodic update - defer to after tracking so we can mask out humans
                    background_update_needed = True
                    logger.print("MAIN", "[BACKGROUND] Deferred background update scheduled (will mask human areas)")
            prev_human_present = current_human_present
        frame_profiler.end_task("human detect")
        
        # 6. Prepare display image (no UI rendering)
        frame_profiler.start_task("display_prep")
        if get_flag("show_raw", False):
            img = raw_img.copy()
        else:
            img = background_img.copy() if background_img is not None else raw_img.copy()
        frame_profiler.end_task("display_prep")
        
        # 7. Pose extraction and tracking
        frame_profiler.start_task("pose_extraction")
        objs = pose_extractor.detect(raw_img, conf_th=0.5, iou_th=0.45, keypoint_th=0.5)
        pose_human_present = len(objs) > 0
        human_present = current_human_present or pose_human_present
        
        human_presence_history.append(human_present)
        if len(human_presence_history) > NO_HUMAN_FRAMES_TO_STOP + 1:
            human_presence_history.pop(0)
        
        # Recording logic
        record_flag = get_flag("record", False)
        now = time_ms()
        
        if record_flag and not is_recording:
            if (len(human_presence_history) >= MIN_HUMAN_FRAMES_TO_START and 
                all(human_presence_history[-MIN_HUMAN_FRAMES_TO_START:])):
                timestamp = get_timestamp_str()
                video_path = f"/root/recordings/{timestamp}.mp4"
                recorder.start(video_path, pose_extractor.input_width(), pose_extractor.input_height())
                skeleton_saver_2d.start_new_log(timestamp)
                frame_id = 0
                recording_start_time = now
                is_recording = True
                update_is_recording(True)
                logger.print("MAIN", "Started recording: %s", timestamp)
        
        if is_recording:
            no_human_count = 0
            for presence in reversed(human_presence_history):
                if not presence:
                    no_human_count += 1
                else:
                    break
            
            no_human_frames_to_stop = NO_HUMAN_SECONDS_TO_STOP * 60
            
            if (no_human_count >= no_human_frames_to_stop or 
                now - recording_start_time >= MAX_RECORDING_DURATION_MS or
                not record_flag):
                recorder.end()
                skeleton_saver_2d.save_to_csv()
                is_recording = False
                update_is_recording(False)
                logger.print("MAIN", "Stopped recording")
        frame_profiler.end_task("pose_extraction")
        
        # 8. Process tracking and collect all tracks into processed_tracks list
        frame_profiler.start_task("tracking")
        tracks = update_tracks(objs)

        if is_recording:
            frame_id += 1

        # Calculate FPS and elapsed time
        frame_end_time = time_ms()
        frame_duration = frame_end_time - frame_start_time
        current_fps = 1000.0 / frame_duration if frame_duration > 0 else 30.0
        set_fps(current_fps)
        frame_start_time = frame_end_time

        # Collect all processed tracks in a single list - single source of truth
        processed_tracks = []
        
        for track in tracks:
            track_result = process_track(
                track, objs, CAMERA_ID,
                is_recording=is_recording,
                skeleton_saver=skeleton_saver_2d if is_recording else None,
                frame_id=frame_id,
                fps=current_fps,
                safety_judgment=safety_judgment
            )
            
            if not track_result:
                continue
            
            logger.print("MAIN", "pose_label <- track_result['pose_label']: %s", track_result.get('pose_label', 'unknown'))
            track_id = track_result.get("track_id")
            keypoints = track_result.get("keypoints")
            bbox = track_result.get("bbox")
            pose_label = track_result.get("pose_label", "unknown")
            # Map "tracking" status to "normal" for safety_status
            status = track_result.get("status", "tracking")
            safety_status = "normal" if status == "tracking" else status
            safety_reason = track_result.get("safety_reason", "normal")
            safety_details = track_result.get("safety_details", {})
            int_features = track_result.get("int_features")

            # Create processed track entry with all required data
            processed_track = {
                "track_id": track_id,
                "keypoints": keypoints,
                "bbox": bbox,
                "pose_label": pose_label,
                "safety_status": safety_status,
                "safety_reason": safety_reason,
                "safety_details": safety_details,
                "int_features": int_features
            }
            processed_tracks.append(processed_track)
        
        # Send all processed tracks at once via queue (fire-and-forget)
        update_latest_tracks(processed_tracks)
        # Signal tracks ready for sending
        mark_tracks_as_ready()
        
        # Cleanup cached_tracks if timeout is hit after the last cache update
        if cached_tracks:
            if time_ms() - cached_tracks_last_updated > cached_tracks_timeout:
                cached_tracks = None 

        # Deferred background update with masking (after we have track bboxes)
        if background_update_needed and background_img is not None:
            try:
                # Extract bounding boxes from processed tracks
                # Get valid tracks (have bbox and keypoints)
                valid_tracks = [t for t in processed_tracks if t.get("bbox") and t.get("keypoints")]

                if valid_tracks:
                    # Merge background with new frame, masking out human areas
                    logger.print("MAIN", "[BACKGROUND] Updating background with %d masked track(s)", len(valid_tracks))
                    new_background = merge_background_with_mask(background_img, raw_img, valid_tracks, padding=20)
                    
                    # Update cached_tracks (and reset `timer`) if valid_track exist
                    cached_tracks_last_updated = time_ms()
                    cached_tracks = valid_tracks
                elif cached_tracks:
                    # No valid tracks for the current frame, but the tracks cache is still available
                    # Workaround for "person(/people) exist in the frame but isn't being detected by the pose extractor"
                    logger.print("MAIN", "[BACKGROUND] Updating background with %d cached track(s)", len(cached_tracks))
                    new_background = merge_background_with_mask(background_img, raw_img, cached_tracks, padding=20)
                else:
                    # No tracks, just use the raw frame
                    logger.print("MAIN", "[BACKGROUND] No tracks to mask, using raw frame")
                    new_background = raw_img.copy()

                # Save and upload the new background
                background_img = new_background
                background_img.save(BACKGROUND_PATH)

                if streaming_server_available:
                    try:
                        jpeg_bytes = background_img.to_jpeg(quality=70).to_bytes(copy=False)
                        frame_upload_worker.update_background(jpeg_bytes)
                        logger.print("MAIN", "[BACKGROUND] Auto-update background queued for upload")
                    except Exception as e:
                        logger.print("MAIN", "[BACKGROUND] Auto-update failed to queue background: %s", e)

                last_update_ms = time_ms()
            except Exception as e:
                logger.print("MAIN", "[BACKGROUND] Error during masked background update: %s", e)
            finally:
                background_update_needed = False

        frame_profiler.end_task("tracking")
        
        # 10. Recording (no display, no UI rendering)
        frame_profiler.start_task("recording")
        if is_recording:
            recorder.add_frame(img)
        frame_profiler.end_task("recording")
        
        # 11. Display to MaixVision
        frame_profiler.start_task("display")
        disp.show(img)
        frame_profiler.end_task("display")
        
        # 12. Update FrameUploadWorker with latest RAW frame (no overlays)
        # Always send raw frame regardless of show_raw flag
        frame_profiler.start_task("frame_upload")
        try:
            jpeg_bytes = raw_img.to_jpeg(quality=60).to_bytes(copy=False)
            frame_upload_worker.update_frame(jpeg_bytes)
        except Exception:
            pass
        frame_profiler.end_task("frame_upload")
        
        # End frame profiling
        frame_profiler.end_frame()
        
        # 13. Periodic garbage collection
        current_time = time_ms()
        if current_time - last_gc_time > GC_INTERVAL_MS:
            gc.collect()
            last_gc_time = current_time
        
        frame_counter += 1
        if frame_counter % 30 == 0:
            logger.print("MAIN", "Frame %d processed", frame_counter)
            if frame_counter % 60 == 0:
                control_flags = get_control_flags()
                logger.print("MAIN", "[STATUS] Flags: record=%s, fall_algorithm=%s",
                          control_flags.get('record'),
                          control_flags.get('fall_algorithm'))

    # ============================================
    # CLEANUP
    # ============================================
    command_receiver.stop()
    flag_sync_worker.stop()
    state_reporter_worker.stop()
    frame_upload_worker.stop()
    ping_worker.stop()
    tracks_sender.stop()
    
    if is_recording:
        recorder.end()
        skeleton_saver_2d.save_to_csv()
    
    from control_manager import save_control_flags
    save_control_flags()
    
    logger.print("MAIN", "=== Camera Stream Stopped ===")
    control_flags = get_control_flags()
    logger.print("MAIN", "Final Configuration:")
    logger.print("MAIN", "  Camera: %s (%s)", CAMERA_NAME, CAMERA_ID)
    logger.print("MAIN", "  Status: %s", registration_status)
    logger.print("MAIN", "  Recording: %s", 'ENABLED' if control_flags.get('record') else 'DISABLED')
    logger.print("MAIN", "  Fall Algorithm: %s", control_flags.get('fall_algorithm'))

if __name__ == "__main__":
    main()

