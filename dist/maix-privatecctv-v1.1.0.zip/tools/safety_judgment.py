from typing import List, Tuple, Optional, Dict
from tools.polygon_checker import CheckMethod
from tools.bed_area_checker import BedAreaChecker
from tools.floor_area_checker import FloorAreaChecker
from tools.chair_area_checker import ChairAreaChecker
from tools.couch_area_checker import CouchAreaChecker
from tools.bench_area_checker import BenchAreaChecker


class SafetyReason:
    """Reason codes for safety status changes"""
    LYING_ON_FLOOR = "lying_on_floor"
    IN_BED_TOO_LONG = "in_bed_too_long"
    SAFE_TRACKING = "safe_tracking"
    SAFE_IN_BED = "safe_in_bed"
    SAFE_IN_CHAIR = "safe_in_chair"
    SAFE_IN_COUCH_SITTING = "safe_in_couch_sitting"
    SAFE_IN_COUCH_LYING = "safe_in_couch_lying_down"
    SAFE_IN_BENCH_SITTING = "safe_in_bench_sitting"
    SAFE_IN_BENCH_LYING = "safe_in_bench_lying_down"
    UNSAFE_SLEEP_TOO_LONG = "unsafe_sleep_too_long"
    UNSAFE_SLEEP_PAST_WAKEUP = "unsafe_sleep_past_wakeup"


class SafetyJudgment:
    """
    Combines results from BedAreaChecker, FloorAreaChecker, and SafeAreaChecker
    to make the final safe/unsafe determination.

    Rules (in order of priority):
    1. Fall detection always takes precedence (handled by caller)
    2. If lying_down AND in_floor_area → UNSAFE (lying on floor)
    3. If in_bed_area AND time > threshold → UNSAFE (in bed too long)
    4. If lying_down AND not_in_safe_area → UNSAFE (lying down outside safe zone)
    5. Otherwise → SAFE (tracking)
    """

    def __init__(self,
                 bed_area_checker: Optional[BedAreaChecker] = None,
                 floor_area_checker: Optional[FloorAreaChecker] = None,
                 chair_area_checker: Optional[ChairAreaChecker] = None,
                 couch_area_checker: Optional[CouchAreaChecker] = None,
                 bench_area_checker: Optional[BenchAreaChecker] = None,
                 check_method: CheckMethod = CheckMethod.TORSO_HEAD):
        """
        Initialize SafetyJudgment.

        Args:
            bed_area_checker: BedAreaChecker instance (optional, can be None)
            floor_area_checker: FloorAreaChecker instance (optional, can be None)
            bench_area_checker: BenchAreaChecker instance (optional, can be None)
            check_method: CheckMethod to use for all area checkers
        """
        self.bed_area_checker = bed_area_checker
        self.floor_area_checker = floor_area_checker
        self.chair_area_checker = chair_area_checker
        self.couch_area_checker = couch_area_checker
        self.bench_area_checker = bench_area_checker
        self.check_method = check_method

    def evaluate_safety(self,
                       track_id: int,
                       body_keypoints: List[Tuple[float, float, float]],
                       pose_label: str,
                       current_time_str: str = "12:00",
                       max_sleep_duration_min: int = 0,
                       bedtime_str: str = "",
                       wakeup_time_str: str = "") -> Tuple[bool, Optional[str], Dict]:
        """
        Evaluate safety status based on all area checkers.

        Reads check_method from control_flags dynamically every call to allow
        runtime changes via web interface.

        Args:
            track_id: The track ID to evaluate
            body_keypoints: List of (x, y, confidence) coordinates for COCO keypoints
            pose_label: Pose classification label (e.g., "lying_down", "standing", etc.)

        Returns:
            Tuple of (is_safe, reason, details)
            - is_safe: False if unsafe, True if safe
            - reason: SafetyReason code or None if safe
            - details: Dictionary with detailed check results for debugging
        """
        # Read check_method from control_flags dynamically
        try:
            from control_manager import get_flag
            check_method_value = get_flag("check_method", 3)
            # Map integer value to CheckMethod enum
            check_method_map = {
                1: CheckMethod.HIP,
                2: CheckMethod.TORSO,
                3: CheckMethod.TORSO_HEAD,
                4: CheckMethod.TORSO_HEAD_KNEES,
                5: CheckMethod.FULL_BODY
            }
            check_method = check_method_map.get(check_method_value, CheckMethod.TORSO_HEAD)
        except ImportError:
            # Fallback to instance check_method if control_manager not available
            check_method = self.check_method

        is_lying_down = pose_label == "lying_down"

        # Initialize details dictionary
        details = {
            "in_bed_area": False,
            "in_floor_area": False,
            "in_floor_area": False,
            "in_chair_area": False,
            "in_couch_area": False,
            "in_bench_area": False,
            "bed_time_ms": 0,
            "bed_status": None,
            "pose_label": pose_label
        }

        # Rule 1: If lying_down AND in_floor_area → UNSAFE (lying on floor)
        if self.floor_area_checker is not None and is_lying_down:
            in_floor = self.floor_area_checker.check_floor_area(body_keypoints, check_method)
            details["in_floor_area"] = in_floor

            if in_floor:
                # Person is lying on the floor - UNSAFE
                return False, SafetyReason.LYING_ON_FLOOR, details

        # Rule 2: Check Bed Area (Smart Monitoring)
        if self.bed_area_checker is not None:
             is_in_bed, time_in_bed, is_bed_unsafe, bed_unsafe_reason = self.bed_area_checker.check_bed_area(
                track_id, body_keypoints,
                current_time_str=current_time_str,
                max_sleep_duration_min=max_sleep_duration_min,
                bedtime_str=bedtime_str,
                wakeup_time_str=wakeup_time_str,
                check_method=check_method
            )
             details["in_bed_area"] = is_in_bed
             details["bed_time_ms"] = time_in_bed * 1000 # Convert back to ms for consistency if needed
             
             if is_in_bed:
                # If lying down or sitting in bed
                if pose_label in ["lying_down", "sitting"]:
                    if is_bed_unsafe:
                        reason = SafetyReason.UNSAFE_SLEEP_TOO_LONG
                        if bed_unsafe_reason == "oversleeping":
                            reason = SafetyReason.UNSAFE_SLEEP_PAST_WAKEUP
                        elif bed_unsafe_reason == "sleep_too_long":
                            reason = SafetyReason.UNSAFE_SLEEP_TOO_LONG
                        
                        return False, reason, details
                    else:
                        return True, SafetyReason.SAFE_IN_BED, details
                # If standing in bed -> fall through to safe tracking

        # Rule 3: Chair area check (only for sitting pose, hips only)
        if self.chair_area_checker is not None and pose_label == "sitting":
            in_chair = self.chair_area_checker.check_chair_area(
                body_keypoints, CheckMethod.HIP
            )
            details["in_chair_area"] = in_chair
            if in_chair:
                return True, SafetyReason.SAFE_IN_CHAIR, details

        # Rule 4: Couch area check (Smart Monitoring)
        if self.couch_area_checker is not None:
            # Couch check needs specific check method logic inside, but our wrapper handles smart monitoring too
            # We need to decide which method to pass.
            # If lying -> TORSO. If sitting -> HIP.
            check_method_couch = CheckMethod.TORSO # default
            if pose_label == "sitting":
                 check_method_couch = CheckMethod.HIP
            
            is_in_couch, time_in_couch, is_couch_unsafe, couch_unsafe_reason = self.couch_area_checker.check_couch_area(
                track_id, body_keypoints,
                current_time_str=current_time_str,
                max_sleep_duration_min=max_sleep_duration_min,
                bedtime_str=bedtime_str,
                wakeup_time_str=wakeup_time_str,
                check_method=check_method_couch
            )
            details["in_couch_area"] = is_in_couch
            
            if is_in_couch:
                if pose_label in ["lying_down", "sitting"]:
                     if is_couch_unsafe:
                        reason = SafetyReason.UNSAFE_SLEEP_TOO_LONG
                        if couch_unsafe_reason == "oversleeping":
                            reason = SafetyReason.UNSAFE_SLEEP_PAST_WAKEUP
                        elif couch_unsafe_reason == "sleep_too_long":
                            reason = SafetyReason.UNSAFE_SLEEP_TOO_LONG
                        
                        return False, reason, details
                     else:
                        reason = SafetyReason.SAFE_IN_COUCH_LYING if pose_label == "lying_down" else SafetyReason.SAFE_IN_COUCH_SITTING
                        return True, reason, details

        # Rule 5: Bench area check (conditional on pose)
        if self.bench_area_checker is not None:
            check_method_bench = None
            reason_suffix = ""
            
            if pose_label == "lying_down":
                check_method_bench = CheckMethod.TORSO
                reason_suffix = "LYING"
            elif pose_label == "sitting":
                check_method_bench = CheckMethod.HIP
                reason_suffix = "SITTING"
            
            if check_method_bench:
                in_bench = self.bench_area_checker.check_bench_area(
                    body_keypoints, check_method_bench
                )
                details["in_bench_area"] = in_bench
                if in_bench:
                    reason = SafetyReason.SAFE_IN_BENCH_LYING if reason_suffix == "LYING" else SafetyReason.SAFE_IN_BENCH_SITTING
                    return True, reason, details

        # Rule 6: Otherwise → SAFE
        return True, SafetyReason.SAFE_TRACKING, details

    def reset_bed_tracking(self, track_id: int):
        """
        Reset bed time tracking for a specific track.

        Call this when a track is lost or re-identified.

        Args:
            track_id: The track ID to reset
        """
        if self.bed_area_checker is not None:
            self.bed_area_checker.reset_track(track_id)

    def clear_all_bed_tracking(self):
        """
        Clear all bed time tracking data.

        Call this when resetting the tracking system.
        """
        if self.bed_area_checker is not None:
            self.bed_area_checker.clear_all_times()

    def get_check_method(self) -> CheckMethod:
        """Get the current check method"""
        return self.check_method

    def set_check_method(self, check_method: CheckMethod):
        """Set the check method for all area checks"""
        self.check_method = check_method
