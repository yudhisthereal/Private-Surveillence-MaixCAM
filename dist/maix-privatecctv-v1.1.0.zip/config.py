# config.py - Server configuration, camera identity, and constants

import os
import json
import time
import socket
import requests

# Load environment variables from .env file
from dotenv import load_dotenv
load_dotenv()

from debug_config import debug_print

# Import CameraStateManager from control_manager for proper state management
from control_manager import camera_state_manager

# ============================================
# LOGGING HELPER
# ============================================
def _log(tag, message):
    """Helper to log messages via LogManager (thread-safe)."""
    from tools.log_manager import get_log_manager
    get_log_manager().log(f"CONFIG {tag}", message)

# ============================================
# SERVER CONFIGURATION (loaded from .env)
# ============================================
STREAMING_SERVER_IP = os.getenv("STREAMING_SERVER_IP", "103.150.93.198")
STREAMING_SERVER_PORT = int(os.getenv("STREAMING_SERVER_PORT", "8000"))
STREAMING_HTTP_URL = f"http://{STREAMING_SERVER_IP}:{STREAMING_SERVER_PORT}"

# ============================================
# CAMERA IDENTITY
# ============================================
CAMERA_INFO_FILE = "/root/camera_info.json"
CAMERA_ID = None
CAMERA_NAME = None

# ============================================
# RECORDING PARAMETERS
# ============================================
MIN_HUMAN_FRAMES_TO_START = 3
NO_HUMAN_FRAMES_TO_STOP = 30  # Will be overridden by NO_HUMAN_SECONDS_TO_STOP
NO_HUMAN_SECONDS_TO_STOP = 5  # 5 seconds at 60fps = 300 frames before confirming no person
MAX_RECORDING_DURATION_MS = 90000

# Background update settings
UPDATE_INTERVAL_MS = 10000
NO_HUMAN_CONFIRM_FRAMES = 10
STEP = 8

# ============================================
# ASYNC WORKER SETTINGS
# ============================================
FLAG_SYNC_INTERVAL_MS = 1000
SAFE_AREA_SYNC_INTERVAL_MS = 5000
STATE_REPORT_INTERVAL_MS = 30000
FRAME_UPLOAD_INTERVAL_MS = 500

# ============================================
# LOCAL FILE PATHS
# ============================================
LOCAL_FLAGS_FILE = "/root/control_flags.json"
SAFE_AREA_FILE = "/root/safe_areas.json"
BACKGROUND_PATH = "/root/static/background.jpg"
LOCAL_PORT = 8080

# Garbage Collection
GC_INTERVAL_MS = 30000

# Pose Analysis
POSE_ANALYSIS_INTERVAL_MS = 50

# Image dimensions for pose estimation (MaixCAM standard resolution)
INPUT_WIDTH = 320
INPUT_HEIGHT = 224



def get_local_ip():
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception as e:
        _log("ERROR", f"Error getting local IP: {e}")
        return "unknown"

def load_camera_info():
    """Load camera ID and name from local file"""
    try:
        if os.path.exists(CAMERA_INFO_FILE):
            with open(CAMERA_INFO_FILE, 'r') as f:
                data = json.load(f)
                camera_id = data.get("camera_id")
                camera_name = data.get("camera_name")
                registration_status = data.get("status", "unregistered")
                ip_address = data.get("ip_address", "")
                last_registration = data.get("last_registration", 0)

                if camera_id and camera_name:
                    _log("INFO", f"Loaded camera info: {camera_name} ({camera_id}) - Status: {registration_status}")
                    return camera_id, camera_name, registration_status, ip_address, last_registration
    except Exception as e:
        _log("ERROR", f"Error loading camera info: {e}")

    return None, None, "unregistered", "", 0

def save_camera_info(camera_id, camera_name, registration_status, ip_address=""):
    """Save camera ID and name to local file"""
    try:
        data = {
            "camera_id": camera_id,
            "camera_name": camera_name,
            "status": registration_status,
            "ip_address": ip_address,
            "last_registration": int(time.time() * 1000),
            "saved_at": int(time.time() * 1000),
            "saved_locally": True
        }

        with open(CAMERA_INFO_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        _log("INFO", f"Camera info saved: {camera_name} ({camera_id}) - Status: {registration_status}")
        return True
    except Exception as e:
        _log("ERROR", f"Error saving camera info: {e}")
        return False

def register_with_streaming_server(server_ip, existing_camera_id=None):
    """Register camera with streaming server (now handles all camera management)"""
    try:
        # First get our local IP
        local_ip = get_local_ip()
        if local_ip == "unknown":
            _log("INFO", "Cannot determine local IP address")
            return "camera_000", "Unnamed Camera", "unregistered", local_ip
        
        url = f"http://{server_ip}:{STREAMING_SERVER_PORT}/api/stream/register"
        
        params = {}
        if existing_camera_id:
            params["camera_id"] = existing_camera_id

        _log("INFO", f"Registering with streaming server: {url} params={params} from IP: {local_ip}")
        # debug_print("INFO", "API_REQUEST", "%s | endpoint: /api/stream/register | params: %s", "POST", str(params))

        response = requests.post(
            url,
            params=params,
            timeout=5.0
        )

        if response.status_code != 200:
            _log("INFO", f"Registration failed: HTTP {response.status_code}")
            return "camera_000", "Unnamed Camera", "unregistered", local_ip

        result = response.json()

        status = result.get("status", "unknown")
        camera_id = result.get("camera_id", "camera_000")
        
        if status == "registered":
            camera_name = result.get("camera_name", f"Camera {camera_id.split('_')[-1]}")
            _log("INFO", f"Camera registered: {camera_name} ({camera_id})")
        elif status == "pending":
            camera_name = f"Camera {camera_id.split('_')[-1]}"
            _log("INFO", f"Camera pending approval: {camera_id}")
            _log("INFO", f"   Please approve registration on the web dashboard")
        else:
            camera_name = f"Camera {camera_id.split('_')[-1]}"
            _log("INFO", f"Unknown status: {status}")

        return camera_id, camera_name, status, local_ip

    except Exception as e:
        _log("INFO", f"Registration error: {e}")
        local_ip = get_local_ip()
        return "camera_000", "Unnamed Camera", "unregistered", local_ip

def check_registration_status(server_ip, camera_id, local_ip):
    """Check if camera is already registered with server"""
    try:
        url = f"http://{server_ip}:{STREAMING_SERVER_PORT}/api/stream/registered"
        _log("INFO", "Checking registration status on streaming server...")
        # debug_print("INFO", "API_REQUEST", "%s | endpoint: /api/stream/registered", "GET")

        response = requests.get(url, timeout=3.0)

        if response.status_code != 200:
            _log("INFO", f"Failed to check registration: HTTP {response.status_code}")
            return "unknown"

        result = response.json()
        cameras = result.get("cameras", [])

        # Camera IP seen by the server != local IP → only check camera_id
        camera_map = {
            cam["camera_id"]: cam
            for cam in cameras
            if "camera_id" in cam
        }

        if camera_id in camera_map:
            _log("INFO", f"Camera {camera_id} found in server registry")
            return "registered"

        _log("INFO", f"Camera {camera_id} not found in server registry")
        return "unregistered"

    except Exception as e:
        _log("INFO", f"Registration check error: {e}")
        return "unknown"


def initialize_camera():
    global CAMERA_ID, CAMERA_NAME
    """Initialize camera by loading existing info or registering new"""
    # Load or register camera
    CAMERA_ID, CAMERA_NAME, registration_status, saved_ip, last_reg = load_camera_info()
    local_ip = get_local_ip()

    _log("INFO", f"=== Camera Initialization ===")
    _log("INFO", f"Loaded from storage: {CAMERA_NAME} ({CAMERA_ID}) - Status: {registration_status}")
    _log("INFO", f"Local IP: {local_ip}")
    _log("INFO", f"Streaming Server: {STREAMING_HTTP_URL}")

    # Always check registration status with server on startup
    if CAMERA_ID and CAMERA_ID != "camera_000":
        server_status = check_registration_status(STREAMING_SERVER_IP, CAMERA_ID, local_ip)
        
        if server_status == "registered":
            # Camera is registered on server
            registration_status = "registered"
            _log("INFO", f"Confirmed: Camera is registered on server")
        elif server_status == "unregistered":
            # Need to re-register
            _log("INFO", f"Camera not registered on server, attempting registration...")
            CAMERA_ID, CAMERA_NAME, registration_status, local_ip = register_with_streaming_server(
                STREAMING_SERVER_IP, 
                existing_camera_id=CAMERA_ID
            )
            # Save the new registration info
            save_camera_info(CAMERA_ID, CAMERA_NAME, registration_status, local_ip)
        else:
            # Server unavailable, use saved status
            _log("INFO", f"Cannot reach server, using saved status: {registration_status}")
    else:
        # First time registration
        _log("INFO", f"First time registration...")
        CAMERA_ID, CAMERA_NAME, registration_status, local_ip = register_with_streaming_server(
            STREAMING_SERVER_IP
        )
        save_camera_info(CAMERA_ID, CAMERA_NAME, registration_status, local_ip)

    _log("INFO", f"=== Final Camera Status ===")
    _log("INFO", f"Camera: {CAMERA_NAME} ({CAMERA_ID})")
    _log("INFO", f"Status: {registration_status}")
    _log("INFO", f"Local IP: {local_ip}")

    # Update CameraStateManager with the final state
    camera_state_manager.set_camera_id(CAMERA_ID, notify=False)
    camera_state_manager.set_camera_name(CAMERA_NAME)
    camera_state_manager.set_registration_status(registration_status, notify=False)
    camera_state_manager.set_local_ip(local_ip)

    return CAMERA_ID, CAMERA_NAME, registration_status, local_ip


